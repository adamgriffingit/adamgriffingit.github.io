
-- Bulk import into STAGE1. 
-- Verify data matches expectation and then copy to STAGE2 where data is typed.
-- Truncate STAGE1 after data copied to STAGE2.

create table STAGE1 (
 [System_Code] VARCHAR(4000),[School_Code] VARCHAR(4000),[System_Name] VARCHAR(4000),[School_Name] VARCHAR(4000),[Year] VARCHAR(4000),[Qtr] VARCHAR(4000),[EOC_or_EOG] VARCHAR(4000),[Grade] VARCHAR(4000),[Subject] VARCHAR(4000),[Number_Tested] VARCHAR(4000),[Mean_Scale_Score] VARCHAR(4000),[Pcnt_Beginning_Learner] VARCHAR(4000),[Pcnt_Developing_Learner] VARCHAR(4000),[Pcnt_Proficient_Learner] VARCHAR(4000),[Pcnt_Distinguished_Learner] VARCHAR(4000),[Pcnt_Developing_Learner_And_Above] VARCHAR(4000),[Pcnt_Proficient_Learner_And_Above] VARCHAR(4000),[RESA] VARCHAR(4000))

--drop table STAGE2
create table STAGE2 (
 [ID] INT IDENTITY(1,1) PRIMARY KEY,[System_Code] INT,[School_Code] INT,[System_Name] VARCHAR(2000),[School_Name] VARCHAR(2000),[Year] INT,[Qtr] VARCHAR(6),[EOC_or_EOG] VARCHAR(3),[Grade] VARCHAR(4),[Subject] VARCHAR(2000),[Number_Tested] INT,[Mean_Scale_Score] DECIMAL(11,8),[Pcnt_Beginning_Learner] DECIMAL(11,8),[Pcnt_Developing_Learner] DECIMAL(11,8),[Pcnt_Proficient_Learner] DECIMAL(11,8),[Pcnt_Distinguished_Learner] DECIMAL(11,8),[Pcnt_Developing_Learner_And_Above] DECIMAL(11,8),[Pcnt_Proficient_Learner_And_Above] DECIMAL(11,8),[RESA] VARCHAR(2000))


-- ---------------------------------------------------
-- Import the EOC files.
-- ---------------------------------------------------

-- Set the values for this import.
declare @yr INT
declare @yrend INT
set @yr = 2014
set @yrend = 2016


-- Setup a table of all the EOC subject names.
declare @subjid INT
declare @subjidmax INT
declare @subjtbl table ( subjid int identity(1,1), subjname char(20) )
insert into @subjtbl values('9th Grade Literature')
insert into @subjtbl values('Algebra I')
insert into @subjtbl values('American Literature')
insert into @subjtbl values('Analytic Geometry')
insert into @subjtbl values('Biology')
insert into @subjtbl values('Coordinate Algebra')
insert into @subjtbl values('Economics')
insert into @subjtbl values('Geometry')
insert into @subjtbl values('Physical Science')
insert into @subjtbl values('US History')
select @subjidmax=count(*) from @subjtbl
--select * from @subjtbl


truncate table STAGE1
while (@yrend>=@yr)
begin
	set @subjid = 1
	while (@subjidmax>=@subjid)
	begin
		-- File name convention: 2014 - Winter - EOC - 9th Grade Literature.txt
		declare @season CHAR(6) --Spring or Winter
		declare @subj VARCHAR(20)
		declare @filename VARCHAR(255)
		declare @sql VARCHAR(1000)
		select @subj=subjname from @subjtbl where subjid=@subjid
		
		set @season = 'Winter'
		set @filename = 'C:\Users\Public\Documents\'+ CONVERT(CHAR(4),@yr) + ' - ' + RTRIM(@season) + ' - EOC - ' + RTRIM(@subj) +'.txt'
		set @sql = 'BULK INSERT STAGE1 FROM ''' + @filename + ''' WITH (FIELDTERMINATOR=''\t'', ROWTERMINATOR=''\n'')'
		print 'Using file: ' + @filename + '.'
		print 'SQL: '+ @sql + '.'
		exec (@sql)
		
		set @season = 'Spring'
		set @filename = 'C:\Users\Public\Documents\'+ CONVERT(CHAR(4),@yr) + ' - ' + RTRIM(@season) + ' - EOC - ' + RTRIM(@subj) +'.txt'
		set @sql = 'BULK INSERT STAGE1 FROM ''' + @filename + ''' WITH (FIELDTERMINATOR=''\t'', ROWTERMINATOR=''\n'')'
		print 'Using file: ' + @filename + '.'
		print 'SQL: '+ @sql + '.'
		exec (@sql)
		
		set @subjid = @subjid +1
	end --/while @subjid
	set @yr = @yr +1
end --/while @yr

--select * from STAGE1
--select distinct [Subject] from STAGE1
--select distinct School_Name from STAGE1






-- ---------------------------------------------------
-- Import the EOG files.
-- ---------------------------------------------------

-- Set the values for this import.
declare @eogyr INT
declare @eogyrend INT
set @eogyr = 2015
set @eogyrend = 2016

--truncate table STAGE1
while (@eogyrend>=@eogyr)
begin
	declare @grade INT
	set @grade = 3
	while (8>=@grade)
	begin
		-- File name convention: 2015 - Spring - EOG - Gr3_School.txt
		declare @eogfilename VARCHAR(255)
		declare @eogsql VARCHAR(1000)
		set @eogfilename = 'C:\Users\Public\Documents\'+ convert(char(4),@eogyr) + ' - Spring - EOG - Gr' + convert(char(1),@grade) +'_School.txt'
		set @eogsql = 'BULK INSERT STAGE1 FROM ''' + @eogfilename + ''' WITH (FIELDTERMINATOR=''\t'', ROWTERMINATOR=''\n'')'
		print 'Using file: ' + @eogfilename + '.'
		print 'SQL: '+ @eogsql + '.'
		exec (@eogsql)
		set @grade = @grade+1
	end
	set @eogyr = @eogyr+1
end

--select * from STAGE1



-- ---------------------------------------------------
-- STAGE1 to STAGE2 cleanup of EOC and EOG records.
-- ---------------------------------------------------

-- Clean up the negative values (essentially a zero result percentage)
-- Clean up the values that are essentially so small they might as well be zero.
-- Note that these fixes were only needed on schools with zero developing/proficient learner scores. Not sure how a calculation would ever be negative?
-- Looking at the data it is clear the percentage score should be zero in that column.
--select * from STAGE1 where Pcnt_Developing_Learner_And_Above like '%E%'
--select * from STAGE1 where Pcnt_Proficient_Learner_And_Above like '%E%'
--update STAGE1 set Pcnt_Developing_Learner_And_Above=0 where Pcnt_Developing_Learner_And_Above like '%E%'
update STAGE1 set Pcnt_Proficient_Learner_And_Above=0 where Pcnt_Proficient_Learner_And_Above like '%E%'

-- Insert the data into STAGE2 for typed data.
--select * from STAGE2
--truncate table STAGE2


/*
-- causes 'String or binary data would be truncated.' errors.
insert into STAGE2
([System_Code],[School_Code],[System_Name],[School_Name],[Year],[Qtr],[EOC_or_EOG],[Grade],[Subject],[Number_Tested],[Mean_Scale_Score],[Pcnt_Beginning_Learner],[Pcnt_Developing_Learner],[Pcnt_Proficient_Learner],[Pcnt_Distinguished_Learner],[Pcnt_Developing_Learner_And_Above],[Pcnt_Proficient_Learner_And_Above],[RESA])
(select [System_Code],[School_Code],[System_Name],[School_Name],[Year],[Qtr],[EOC_or_EOG],[Grade],[Subject],[Number_Tested]
,[Mean_Scale_Score]
,[Pcnt_Beginning_Learner]
,[Pcnt_Developing_Learner]
,[Pcnt_Proficient_Learner]
,[Pcnt_Distinguished_Learner]
,[Pcnt_Developing_Learner_And_Above]
,[Pcnt_Proficient_Learner_And_Above]
,[RESA] 
from STAGE1)
*/

-- Put a key on the bulk data.
drop table STAGETEMP
;WITH CTE AS ( SELECT * FROM STAGE1 )
SELECT IDENTITY(INT,1,1) AS PKID, * INTO STAGETEMP FROM CTE
--select * from STAGETEMP
-- 54,624 records


-- Insert 20 at a time to detect any records causing 'String or binary data would be truncated.' errors.
truncate table STAGE2
declare @pk as int
declare @max as int
set @pk=1
select @max=count(*) from STAGETEMP
print 'Performing per record attempt for '+convert(varchar(8),@max)+' records.'
while (@max>=@pk)
begin
	print 'Record: ' + convert(varchar(8),@pk)
	insert into STAGE2
	([System_Code],[School_Code],[System_Name],[School_Name],[Year],[Qtr],[EOC_or_EOG],[Grade],[Subject],[Number_Tested],[Mean_Scale_Score],[Pcnt_Beginning_Learner],[Pcnt_Developing_Learner],[Pcnt_Proficient_Learner],[Pcnt_Distinguished_Learner],[Pcnt_Developing_Learner_And_Above],[Pcnt_Proficient_Learner_And_Above],[RESA])
	(select [System_Code],[School_Code],[System_Name],[School_Name],[Year],[Qtr],[EOC_or_EOG],[Grade],[Subject],[Number_Tested]
	,[Mean_Scale_Score]
	,[Pcnt_Beginning_Learner]
	,[Pcnt_Developing_Learner]
	,[Pcnt_Proficient_Learner]
	,[Pcnt_Distinguished_Learner]
	,[Pcnt_Developing_Learner_And_Above]
	,[Pcnt_Proficient_Learner_And_Above]
	,[RESA]
	from STAGETEMP --)
	where PKID>=@pk and PKID <(@pk+20) )
	set @pk = @pk +20
end

/*
Record: 50161
Msg 8152, Level 16, State 14, Line 9
String or binary data would be truncated.
Record: 52381
Msg 8152, Level 16, State 14, Line 9
String or binary data would be truncated.

select * from STAGETEMP where PKID>=50161 AND PKID<=52381
*/


-- System 782 is a naming mess. Fix it now to prevent future problems.
--select distinct System_Code, School_Code, System_Name, School_Name from STAGE2 where System_Code=782
update STAGE2 set System_Name='SCS' where System_Code=782

-- System 745 is a hyphen/no-hyphen problem. Fixing it now to prevent future problems.
--select distinct System_Code, School_Code, System_Name, School_Name from STAGE2 where System_Code=745
update STAGE2 set System_Name='THOMASTON UPSON COUNTY' where System_Code=745

-- Might as well go ahead and clean up the quotes
update STAGE2 set School_Name = REPLACE(School_Name,'"','')
update STAGE2 set System_Name = REPLACE(System_Name,'"','')


-- Correct for variations in System_Name and School_Name.
-- Favoring the longer version as the more descriptive.
-- See the issue with this query.
-- select distinct System_Code, School_Code, School_Name from STAGE2


-- Correcting variations in School_Name
update STAGE2 set School_Name=upd.School_Name
from
(
	select SchLen.System_Code,SchNm.School_Code,SchNm.School_Name
	from
	(
	select System_Code, School_Code, max(School_Name_Length) School_Name_Length
	from (select distinct System_Code, School_Code, School_Name, len(School_Name) School_Name_Length from STAGE2) SchoolLength
	group by System_Code, School_Code
	) SchLen
	inner join 
	(select distinct System_Code, School_Code, School_Name, len(School_Name) School_Name_Length from STAGE2) SchNm
	on SchLen.System_Code=SchNm.System_Code and SchLen.School_Code=SchNm.School_Code and SchLen.School_Name_Length=SchNm.School_Name_Length
	--2,282 rows
	--select distinct System_Code, School_Code from STAGE2
) upd
where STAGE2.System_Code=upd.System_Code and STAGE2.School_Code=upd.School_Code


-- Correcting variations in System_Name
update STAGE2 set System_Name=upd.System_Name
from
(
	select SysLen.System_Code,SysNm.System_Name
	from
	(
	select System_Code, max(System_Name_Length) System_Name_Length
	from (select distinct System_Code, System_Name, len(System_Name) System_Name_Length from STAGE2) SystemLength
	group by System_Code
	) SysLen
	inner join 
	(select distinct System_Code, System_Name, len(System_Name) System_Name_Length from STAGE2) SysNm
	on SysLen.System_Code=SysNm.System_Code and SysLen.System_Name_Length=SysNm.System_Name_Length
	--202 rows
	--select distinct System_Code from STAGE2
) upd
where STAGE2.System_Code=upd.System_Code





/*
select * from STAGE2 where Pcnt_Proficient_Learner_And_Above = 0
select * from STAGE2 where ID=534
select * from STAGE1 where System_Code=746 AND School_Code=198 and Year=2014 and Number_Tested=111
select max(Mean_Scale_Score) from STAGE1
select max(Mean_Scale_Score) from STAGE2
*/