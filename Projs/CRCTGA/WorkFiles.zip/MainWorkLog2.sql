--raw data downloaded here: http://www.gadoe.org/Curriculum-Instruction-and-Assessment/Assessment/Pages/CRCT-Statewide-Scores.aspx



use adgtest

-- create stage area 1 for bulk imports
CREATE TABLE STAGE1_CRCT (
[Key] VARCHAR(4000)
,[System_name] VARCHAR(4000)
,[School_name] VARCHAR(4000)
,[N_Tested_Reading] VARCHAR(4000)
,[Reading_Mean_Scale_Score] VARCHAR(4000)
,[Reading__Did_not_meet_the_standard] VARCHAR(4000)
,[Reading__Meets_the_standard] VARCHAR(4000)
,[Reading__Exceeds_the_standard] VARCHAR(4000)
,[Reading__Met_or_Exceeded_the_standard] VARCHAR(4000)
,[N_Tested_ELA] VARCHAR(4000)
,[ELA_Mean_Scale_Score] VARCHAR(4000)
,[ELA__Did_not_meet_the_standard] VARCHAR(4000)
,[ELA__Meets_the_standard] VARCHAR(4000)
,[ELA__Exceeds_the_standard] VARCHAR(4000)
,[ELA__Met_or_Exceeded_the_standard] VARCHAR(4000)
,[N_Tested_Math] VARCHAR(4000)
,[Math_Mean_Scale_Score] VARCHAR(4000)
,[Math__Did_not_meet_the_standard] VARCHAR(4000)
,[Math__Meets_the_standard] VARCHAR(4000)
,[Math__Exceeds_the_standard] VARCHAR(4000)
,[Math__Met_or_Exceeded_the_standard] VARCHAR(4000)
,[N_Tested_Science] VARCHAR(4000)
,[Science_Mean_Scale_Score] VARCHAR(4000)
,[Science__Does_not_meet_standard] VARCHAR(4000)
,[Science__Meets_the_standard] VARCHAR(4000)
,[Science__Exceeds_the_standard] VARCHAR(4000)
,[Science__Met_or_Exceeded_the_standard] VARCHAR(4000)
,[N_Tested_Social_Studies] VARCHAR(4000)
,[Social_Studies_Mean_Scale_Score] VARCHAR(4000)
,[Social_Studies__Does_not_meet_the_standard] VARCHAR(4000)
,[Social_Studies__Meets_the_standard] VARCHAR(4000)
,[Social_Studies__Exceeds_the_standard] VARCHAR(4000)
,[Social_Studies__Met_or_Exceeded_the_standard] VARCHAR(4000)
,[RESA] VARCHAR(4000)
,[Congressional_District] VARCHAR(4000)
)

-- create stage area 1 for bulk imports (2010 data missing last two columns)
CREATE TABLE STAGE1_CRCT_2010 (
[Key] VARCHAR(4000)
,[System_name] VARCHAR(4000)
,[School_name] VARCHAR(4000)
,[N_Tested_Reading] VARCHAR(4000)
,[Reading_Mean_Scale_Score] VARCHAR(4000)
,[Reading__Did_not_meet_the_standard] VARCHAR(4000)
,[Reading__Meets_the_standard] VARCHAR(4000)
,[Reading__Exceeds_the_standard] VARCHAR(4000)
,[Reading__Met_or_Exceeded_the_standard] VARCHAR(4000)
,[N_Tested_ELA] VARCHAR(4000)
,[ELA_Mean_Scale_Score] VARCHAR(4000)
,[ELA__Did_not_meet_the_standard] VARCHAR(4000)
,[ELA__Meets_the_standard] VARCHAR(4000)
,[ELA__Exceeds_the_standard] VARCHAR(4000)
,[ELA__Met_or_Exceeded_the_standard] VARCHAR(4000)
,[N_Tested_Math] VARCHAR(4000)
,[Math_Mean_Scale_Score] VARCHAR(4000)
,[Math__Did_not_meet_the_standard] VARCHAR(4000)
,[Math__Meets_the_standard] VARCHAR(4000)
,[Math__Exceeds_the_standard] VARCHAR(4000)
,[Math__Met_or_Exceeded_the_standard] VARCHAR(4000)
,[N_Tested_Science] VARCHAR(4000)
,[Science_Mean_Scale_Score] VARCHAR(4000)
,[Science__Does_not_meet_standard] VARCHAR(4000)
,[Science__Meets_the_standard] VARCHAR(4000)
,[Science__Exceeds_the_standard] VARCHAR(4000)
,[Science__Met_or_Exceeded_the_standard] VARCHAR(4000)
,[N_Tested_Social_Studies] VARCHAR(4000)
,[Social_Studies_Mean_Scale_Score] VARCHAR(4000)
,[Social_Studies__Does_not_meet_the_standard] VARCHAR(4000)
,[Social_Studies__Meets_the_standard] VARCHAR(4000)
,[Social_Studies__Exceeds_the_standard] VARCHAR(4000)
,[Social_Studies__Met_or_Exceeded_the_standard] VARCHAR(4000)
)


-- create stage area 2 for import plus other info (year and grade level)
CREATE TABLE STAGE2_CRCT (
ID INT IDENTITY(1,1) PRIMARY KEY
,[yr] INT
,[grade] INT
,[Key] VARCHAR(4000)
,[System_name] VARCHAR(4000)
,[School_name] VARCHAR(4000)
,[N_Tested_Reading] VARCHAR(4000)
,[Reading_Mean_Scale_Score] VARCHAR(4000)
,[Reading__Did_not_meet_the_standard] VARCHAR(4000)
,[Reading__Meets_the_standard] VARCHAR(4000)
,[Reading__Exceeds_the_standard] VARCHAR(4000)
,[Reading__Met_or_Exceeded_the_standard] VARCHAR(4000)
,[N_Tested_ELA] VARCHAR(4000)
,[ELA_Mean_Scale_Score] VARCHAR(4000)
,[ELA__Did_not_meet_the_standard] VARCHAR(4000)
,[ELA__Meets_the_standard] VARCHAR(4000)
,[ELA__Exceeds_the_standard] VARCHAR(4000)
,[ELA__Met_or_Exceeded_the_standard] VARCHAR(4000)
,[N_Tested_Math] VARCHAR(4000)
,[Math_Mean_Scale_Score] VARCHAR(4000)
,[Math__Did_not_meet_the_standard] VARCHAR(4000)
,[Math__Meets_the_standard] VARCHAR(4000)
,[Math__Exceeds_the_standard] VARCHAR(4000)
,[Math__Met_or_Exceeded_the_standard] VARCHAR(4000)
,[N_Tested_Science] VARCHAR(4000)
,[Science_Mean_Scale_Score] VARCHAR(4000)
,[Science__Does_not_meet_standard] VARCHAR(4000)
,[Science__Meets_the_standard] VARCHAR(4000)
,[Science__Exceeds_the_standard] VARCHAR(4000)
,[Science__Met_or_Exceeded_the_standard] VARCHAR(4000)
,[N_Tested_Social_Studies] VARCHAR(4000)
,[Social_Studies_Mean_Scale_Score] VARCHAR(4000)
,[Social_Studies__Does_not_meet_the_standard] VARCHAR(4000)
,[Social_Studies__Meets_the_standard] VARCHAR(4000)
,[Social_Studies__Exceeds_the_standard] VARCHAR(4000)
,[Social_Studies__Met_or_Exceeded_the_standard] VARCHAR(4000)
,[RESA] VARCHAR(4000)
,[Congressional_District] VARCHAR(4000)
)

-- Only one of the files had an additional column named "Reading: Mean Total Correct". 
-- It was file CRCT_Grade5_2013_school.xls so that column was deleted and save as tab delim redone.

TRUNCATE TABLE STAGE2_CRCT

DECLARE @yr INT
DECLARE @grade INT
SET @yr = 2013
SET @grade = 8

WHILE (2011<=@yr)
BEGIN
SET @grade = 8
WHILE (3<=@grade)
BEGIN
	-- File name convention: CRCT_Grade7_2012_school.txt
	DECLARE @filename VARCHAR(255)
	SET @filename = 'C:\Users\Public\CRCT\CRCT_Grade'+ CONVERT(CHAR(1),@grade) +'_'+ CONVERT(CHAR(4),@yr) +'_school.txt'
	DECLARE @sql VARCHAR(1000)
	SET @sql = 'BULK INSERT STAGE1_CRCT FROM ''' + RTRIM(@filename) + ''' WITH (FIELDTERMINATOR=''\t'', ROWTERMINATOR=''\n'')'
	PRINT 'Using file: ' + RTRIM(@filename) + '.'
	PRINT 'SQL: '+ RTRIM(@sql) + '.'
	TRUNCATE TABLE STAGE1_CRCT
	EXEC (@sql)
	INSERT INTO STAGE2_CRCT ([yr],[grade],[Key],[System_name],[School_name],[N_Tested_Reading],[Reading_Mean_Scale_Score],[Reading__Did_not_meet_the_standard],[Reading__Meets_the_standard],[Reading__Exceeds_the_standard],[Reading__Met_or_Exceeded_the_standard],[N_Tested_ELA],[ELA_Mean_Scale_Score],[ELA__Did_not_meet_the_standard],[ELA__Meets_the_standard],[ELA__Exceeds_the_standard],[ELA__Met_or_Exceeded_the_standard],[N_Tested_Math],[Math_Mean_Scale_Score],[Math__Did_not_meet_the_standard],[Math__Meets_the_standard],[Math__Exceeds_the_standard],[Math__Met_or_Exceeded_the_standard],[N_Tested_Science],[Science_Mean_Scale_Score],[Science__Does_not_meet_standard],[Science__Meets_the_standard],[Science__Exceeds_the_standard],[Science__Met_or_Exceeded_the_standard],[N_Tested_Social_Studies],[Social_Studies_Mean_Scale_Score],[Social_Studies__Does_not_meet_the_standard],[Social_Studies__Meets_the_standard],[Social_Studies__Exceeds_the_standard],[Social_Studies__Met_or_Exceeded_the_standard],[RESA],[Congressional_District])
	(
	SELECT @yr, @grade, * FROM STAGE1_CRCT
	)
SET @grade = @grade -1
END --WHILE @grade
SET @yr = @yr -1
END --WHILE @yr


-- Error when starting load from 2010 data, grade 8. 2010 data does not have last two columns that newer files had.


DECLARE @yr INT
DECLARE @grade INT
SET @yr = 2010
SET @grade = 8

WHILE (2010<=@yr)
BEGIN
SET @grade = 8
WHILE (3<=@grade)
BEGIN
	-- File name convention: CRCT_Grade7_2012_school.txt
	DECLARE @filename VARCHAR(255)
	SET @filename = 'C:\Users\Public\CRCT\CRCT_Grade'+ CONVERT(CHAR(1),@grade) +'_'+ CONVERT(CHAR(4),@yr) +'_school.txt'
	DECLARE @sql VARCHAR(1000)
	SET @sql = 'BULK INSERT STAGE1_CRCT_2010 FROM ''' + RTRIM(@filename) + ''' WITH (FIELDTERMINATOR=''\t'', ROWTERMINATOR=''\n'')'
	PRINT 'Using file: ' + RTRIM(@filename) + '.'
	PRINT 'SQL: '+ RTRIM(@sql) + '.'
	TRUNCATE TABLE STAGE1_CRCT_2010
	EXEC (@sql)
	INSERT INTO STAGE2_CRCT ([yr],[grade],[Key],[System_name],[School_name],[N_Tested_Reading],[Reading_Mean_Scale_Score],[Reading__Did_not_meet_the_standard],[Reading__Meets_the_standard],[Reading__Exceeds_the_standard],[Reading__Met_or_Exceeded_the_standard],[N_Tested_ELA],[ELA_Mean_Scale_Score],[ELA__Did_not_meet_the_standard],[ELA__Meets_the_standard],[ELA__Exceeds_the_standard],[ELA__Met_or_Exceeded_the_standard],[N_Tested_Math],[Math_Mean_Scale_Score],[Math__Did_not_meet_the_standard],[Math__Meets_the_standard],[Math__Exceeds_the_standard],[Math__Met_or_Exceeded_the_standard],[N_Tested_Science],[Science_Mean_Scale_Score],[Science__Does_not_meet_standard],[Science__Meets_the_standard],[Science__Exceeds_the_standard],[Science__Met_or_Exceeded_the_standard],[N_Tested_Social_Studies],[Social_Studies_Mean_Scale_Score],[Social_Studies__Does_not_meet_the_standard],[Social_Studies__Meets_the_standard],[Social_Studies__Exceeds_the_standard],[Social_Studies__Met_or_Exceeded_the_standard])
	(
	SELECT @yr, @grade, * FROM STAGE1_CRCT_2010
	)
SET @grade = @grade -1
END --WHILE @grade
SET @yr = @yr -1
END --WHILE @yr


-- create staging area 3 for more relevant records and fields
CREATE TABLE STAGE3_CRCT (
[ID] INT IDENTITY(1,1)
,[Key] INT
,[Year] INT
,[SystemName] NCHAR(254)
,[SchoolName] NCHAR(254)
,[Grade] INT
,[Subject] NCHAR(50)
,[NumberTested] INT
,[DidNotMeet] DEC
,[Met] DEC
,[Exceeded] DEC
)


INSERT INTO STAGE3_CRCT ([Key],[Year],[SystemName],[SchoolName],[Grade],[Subject],[NumberTested],[DidNotMeet],[Met],[Exceeded])
(
	SELECT [Key],[yr],[SystemName],[SchoolName],[grade],[Subject],CONVERT(INT,[NumberTested]) [NumberTested],CONVERT(DEC,[DidNotMeet]) [DidNotMeet],CONVERT(DEC,[Met]) [Met],CONVERT(DEC,[Exceeded]) [Exceeded]
	FROM (
		SELECT [Key],[yr],[SystemName],[SchoolName],[grade],[Subject],[NumberTested],[DidNotMeet],[Met],[Exceeded]
		FROM (
			SELECT [Key],[yr],[System_name] [SystemName],[School_name] [SchoolName],[grade],'reading' [Subject],[N_Tested_Reading] [NumberTested],[Reading__Did_not_meet_the_standard] [DidNotMeet],[Reading__Meets_the_standard] [Met],[Reading__Exceeds_the_standard] [Exceeded]
			FROM STAGE2_CRCT
			UNION ALL
			SELECT [Key],[yr],[System_name],[School_name],[grade],'ELA'[Subject],[N_Tested_ELA],[ELA__Did_not_meet_the_standard],[ELA__Meets_the_standard],[ELA__Exceeds_the_standard]
			FROM STAGE2_CRCT
			UNION ALL
			SELECT [Key],[yr],[System_name],[School_name],[grade],'math'[Subject],[N_Tested_Math],[Math__Did_not_meet_the_standard],[Math__Meets_the_standard],[Math__Exceeds_the_standard]
			FROM STAGE2_CRCT
			UNION ALL
			SELECT [Key],[yr],[System_name],[School_name],[grade],'science'[Subject],[N_Tested_Science],[Science__Does_not_meet_standard],[Science__Meets_the_standard],[Science__Exceeds_the_standard]
			FROM STAGE2_CRCT
			UNION ALL
			SELECT [Key],[yr],[System_name],[School_name],[grade],'social'[Subject],[N_Tested_Social_Studies],[Social_Studies__Does_not_meet_the_standard],[Social_Studies__Meets_the_standard],[Social_Studies__Exceeds_the_standard]
			FROM STAGE2_CRCT
		) ua
		WHERE [SystemName] is not null 
		AND [SystemName] <> 'System name'
		AND 1=ISNUMERIC([DidNotMeet])
		AND 1=ISNUMERIC([Met])
		AND 1=ISNUMERIC([Exceeded])
		AND [DidNotMeet] NOT LIKE '%-%'
		AND [Met] NOT LIKE '%-%'
		AND [Exceeded] NOT LIKE '%-%'
	) wh
)






-- Testing
SELECT * FROM STAGE1_CRCT WHERE [Key] like '%6220705%'
SELECT * FROM STAGE2_CRCT WHERE '6220705'=[Key]
SELECT * from STAGE3_CRCT WHERE '6220705'=[Key] AND 2013=[Year] AND 5=[Grade]
SELECT DISTINCT [Year] from STAGE3_CRCT
